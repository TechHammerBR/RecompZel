@echo off
rem Teste do flicker de cor (RTX 4080): as duas mudancas juntas (A e B).
rem Abre o launcher normal (com as suas opcoes) e o jogo herda as variaveis. Nada fica gravado no Windows.
cd /d "%~dp0"
set RX_VK_PER_QUEUE_FENCES=0
set RX_VK_WAIT_GPU=1
if exist "%~dp0RecompZel Launcher.exe" (
    start "" "%~dp0RecompZel Launcher.exe"
) else if exist "%~dp0RecompZel.exe" (
    start "" "%~dp0RecompZel.exe"
) else (
    echo Coloque este arquivo na mesma pasta do "RecompZel Launcher.exe" ou do "RecompZel.exe".
    pause
)
