@echo off
rem Teste do flicker de cor (RTX 4080): RX_VK_WAIT_GPU=1, a traducao nao passa mais de um quadro na frente da placa (o volume de neblina lido um quadro antes, issue 570).
rem Abre o launcher normal (com as suas opcoes) e o jogo herda as variaveis. Nada fica gravado no Windows.
cd /d "%~dp0"
set RX_VK_WAIT_GPU=1
if exist "%~dp0RecompZel Launcher.exe" (
    start "" "%~dp0RecompZel Launcher.exe"
) else if exist "%~dp0RecompZel.exe" (
    start "" "%~dp0RecompZel.exe"
) else (
    echo Coloque este arquivo na mesma pasta do "RecompZel Launcher.exe" ou do "RecompZel.exe".
    pause
)
